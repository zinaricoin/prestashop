<?php				    	
header("Location: ../");
exit;