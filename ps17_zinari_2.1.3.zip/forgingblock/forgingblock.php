<?php
/**
 * FORGINGBLOCK
 * Copyright (c) 2019-2020 Forging Technologies, Inc. MIT license
 */
use PrestaShop\PrestaShop\Core\Payment\PaymentOption; 
require_once(dirname(__FILE__) . '/lib/Forgingblock.php');	

if (!defined('_PS_VERSION_'))
    exit;


class Forgingblock extends PaymentModule
{
    public function __construct()
    {
        $this->name = 'forgingblock';
        $this->tab = 'payments_gateways';
        $this->version = '2.1.3';
        $this->author = 'Forgingblock';
        $this->need_instance = 1;
        $this->bootstrap = true;       
		
		
        $this->ps_versions_compliancy = array(
            'min' => '1.7',
            'max' => _PS_VERSION_
        );


        parent::__construct();
		
		$this->meta_title = $this->l('forgingblock');
		$this->displayName = 'forgingblock';
        $this->description = $this->l('ForgingBlock Cryptocurrency Gateway PrestaShop');	

    }

    public function install()
    {
        if (!parent::install() || !$this->registerHook('paymentOptions') || !$this->registerHook('adminOrder')            
        ) {
            return false;
        }

        return true;

    }
	
	
    public function hookPaymentOptions($params)
    {
        return $this->forgingblockPaymentOptions($params);
    }
	
   	
    public static function setOrderStatus($oid, $status)
    {
        $order_history = new OrderHistory();
        $order_history->id_order = (int)$oid;
        $order_history->changeIdOrderState((int)$status, (int)$oid, true);
        $order_history->addWithemail(true);        
    }
	

	public function returnsuccess($params){
		
		$invoice_id = $params['id'];		
		
		$tmode  = (Configuration::get('FORGINGBLOCK_MODE') == 'N') ? 'live' : 'test';
		$forgingblock = new \ForgingblockAPI($tmode);
		$forgingblock->SetValue('trade',  Configuration::get('FORGINGBLOCK_TRADE_ID'));
		$forgingblock->SetValue('token', Configuration::get('FORGINGBLOCK_TOKEN'));
		$forgingblock->SetValue('invoice', $invoice_id);		
		$resar = $forgingblock->CheckInvoiceStatus();
		$cart_id = $resar['order'];		
		
		$order_id = Order::getOrderByCartId($cart_id);

		$order_paid_statusid  = empty(Configuration::get( 'FORGINGBLOCK_PAID_SID' )) ? 2 : Configuration::get( 'FORGINGBLOCK_PAID_SID' );			
		$order_confirmed_statusid  = empty(Configuration::get( 'FORGINGBLOCK_CONFIRMED_SID' )) ? 2 : Configuration::get( 'FORGINGBLOCK_CONFIRMED_SID' );		
		$order_complete_statusid  = empty(Configuration::get( 'FORGINGBLOCK_COMPLETE_SID' )) ? 2 : Configuration::get( 'FORGINGBLOCK_COMPLETE_SID' );	
		$order_invalid_statusid = empty(Configuration::get( 'FORGINGBLOCK_INVALID_SID' )) ? 8 : Configuration::get( 'FORGINGBLOCK_INVALID_SID' );
		
		$payment_status = $forgingblock->GetInvoiceStatus();
		
		
		switch ($payment_status) {

                    case 'paid':                     				
                        	$this->setOrderStatus($order_id, $order_paid_statusid) ;
                        break;
                    
                    case 'confirmed':
						$this->setOrderStatus($order_id, $order_confirmed_statusid) ;                        
                        break;
                    case 'complete':
						$this->setOrderStatus($order_id, $order_complete_statusid) ;                                                
                        break;
                    
                    case 'invalid':
						$this->setOrderStatus($order_id, $order_invalid_statusid) ;                                                                       
                        break;

                    case 'expired':
						$this->setOrderStatus($order_id, $order_invalid_statusid) ;                        
                        break;                    
                    default:

                        error_log('    [Info] IPN response is an unknown message type. See error message below:');
                        $error_string = 'Unhandled invoice status: ' . $payment_status;
                        error_log("    [Warning] $error_string");
                }
		 			
				
		
	}
	

	
    /**
     * Uninstall and clean the module settings
     *
     * @return	bool
     */
    public function uninstall()
    {
        parent::uninstall();

        Db::getInstance()->Execute('DELETE FROM `'._DB_PREFIX_.'module_country` WHERE `id_module` = '.(int)$this->id);

        return (true);
    }

	
    public function getContent()
    {
        if (Tools::isSubmit('submit' . $this->name)) {
			
		$forgingblock_name = Tools::getValue('forgingblock_name');
		$saveOpt = false;
		$err_msg = '';
		if (empty(Tools::getValue('forgingblock_trade_id'))) $err_msg = 'Trade ID must have value';
		if (empty(Tools::getValue('forgingblock_token'))) $err_msg = 'Token must have value';			
		
			
		if (empty($err_msg)) $saveOpt = true;
			
        if ($saveOpt)
		{							
			
			Configuration::updateValue('FORGINGBLOCK_TRADE_ID', pSQL(Tools::getValue('forgingblock_trade_id')));
			Configuration::updateValue('FORGINGBLOCK_TOKEN', pSQL(Tools::getValue('forgingblock_token')));			
			Configuration::updateValue('FORGINGBLOCK_NEW_SID', pSQL(Tools::getValue('forgingblock_order_new_status')));
			Configuration::updateValue('FORGINGBLOCK_PAID_SID', pSQL(Tools::getValue('forgingblock_order_paid_status')));			
			Configuration::updateValue('FORGINGBLOCK_CONFIRMED_SID', pSQL(Tools::getValue('forgingblock_order_confirmed_status')));
			Configuration::updateValue('FORGINGBLOCK_COMPLETE_SID', pSQL(Tools::getValue('forgingblock_order_complete_status')));			
			Configuration::updateValue('FORGINGBLOCK_INVALID_SID', pSQL(Tools::getValue('forgingblock_order_invalid_status')));			
			
			Configuration::updateValue('FORGINGBLOCK_MODE', pSQL(Tools::getValue('forgingblock_mode')));			
																		
			$html = '<div class="alert alert-success">'.$this->l('Configuration updated successfully').'</div>';			
		}
		else
		{
				$html = '<div class="alert alert-warning">'.$this->l($err_msg).'</div>';			
		}
        }

		$states = 	OrderState::getOrderStates((int) Configuration::get('PS_LANG_DEFAULT'));
		foreach ($states as $state)		
		{
			$OrderStates[$state['id_order_state']] = $state['name'];
			}
		
		$order_new_statusid =  empty(Configuration::get('FORGINGBLOCK_NEW_SID')) ? 3 : Configuration::get('FORGINGBLOCK_NEW_SID');
		$order_paid_statusid  = empty(Configuration::get( 'FORGINGBLOCK_PAID_SID' )) ? 2 : Configuration::get( 'FORGINGBLOCK_PAID_SID' );			
		$order_confirmed_statusid  = empty(Configuration::get( 'FORGINGBLOCK_CONFIRMED_SID' )) ? 2 : Configuration::get( 'FORGINGBLOCK_CONFIRMED_SID' );		
		$order_complete_statusid  = empty(Configuration::get( 'FORGINGBLOCK_COMPLETE_SID' )) ? 2 : Configuration::get( 'FORGINGBLOCK_COMPLETE_SID' );	
		$order_invalid_statusid = empty(Configuration::get( 'FORGINGBLOCK_INVALID_SID' )) ? 8 : Configuration::get( 'FORGINGBLOCK_INVALID_SID' );	
		
        $data    = array(
            'base_url'    => _PS_BASE_URL_ . __PS_BASE_URI__,
            'module_name' => $this->name,            
			'forgingblock_trade_id' => Configuration::get('FORGINGBLOCK_TRADE_ID'),
			'forgingblock_token' => Configuration::get('FORGINGBLOCK_TOKEN'),		        
            'forgingblock_mode' => Configuration::get('FORGINGBLOCK_MODE'),	
            'forgingblock_order_new_status' => $order_new_statusid,			
			'forgingblock_order_paid_status' => $order_paid_statusid,
			'forgingblock_order_confirmed_status' => $order_confirmed_statusid,
			'forgingblock_order_complete_status' => $order_complete_statusid,			
			'forgingblock_order_invalid_status' => $order_invalid_statusid,			
			'forgingblock_confirmation' => $html,			
            'orderstates' => $OrderStates,	
        );


        $this->context->smarty->assign($data);	
        $output = $this->display(__FILE__, 'tpl/admin.tpl');

        return $output;
    }
	
	
	//1.7

    public function forgingblockPaymentOptions($params)
    {

        if (!$this->active) {
            return;
        }
        if (!$this->checkCurrency($params['cart'])) {
            return;
        }
        $payment_options = [
            $this->forgingblockExternalPaymentOption(),
        ];
        return $payment_options;
    }

    public function checkCurrency($cart)
    {
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);

        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }

    public function forgingblockExternalPaymentOption()
    {
        $lang = Tools::strtolower($this->context->language->iso_code);
		if (isset($_GET['forgingblockerror'])) $errmsg = $_GET['forgingblockerror'];
        $this->context->smarty->assign(array(
            'module_dir' => $this->_path,
            'errmsg' => $errmsg,			
        ));		
		
		$url = $this->context->link->getModuleLink('forgingblock', 'payment');
		
        $newOption = new PaymentOption();
        $newOption->setCallToActionText($this->l('Pay with Forgingblock'))
			->setAction($url)
            ->setAdditionalInformation($this->context->smarty->fetch('module:forgingblock/tpl/payment_infos.tpl'));

        return $newOption;
    }

    public function forgingblockPaymentReturnNew($params)
    {
        // Payement return for PS 1.7
        if ($this->active == false) {
            return;
        }
        $order = $params['order'];
        if ($order->getCurrentOrderState()->id != Configuration::get('PS_OS_ERROR')) {
            $this->smarty->assign('status', 'ok');
        }
		
		
        $this->smarty->assign(array(
            'id_order' => $order->id,
            'reference' => $order->reference,					
            'params' => $params,
            'total_to_pay' => Tools::displayPrice($order->total_paid, null, false),
            'shop_name' => $this->context->shop->name,
        ));
        return $this->fetch('module:' . $this->name . '/tpl/order-confirmation.tpl');
    }
	
	
	public function getUrl()
    {        				
		$cart = $this->context->cart;
		$customer = new Customer($cart->id_customer);
		
		
		$amount = number_format($cart->getOrderTotal(true, Cart::BOTH),2);
		$order_id = $cart->id;				
				
		$iaddress = new Address($cart->id_address_invoice);				
		$icountry_code = Country::getIsoById($iaddress->id_country) ;		
		$total = ($cart->getOrderTotal());
		$ps_currency  = new Currency((int)($cart->id_currency));
		$currency_code = $ps_currency->iso_code;
		
				
		$returnURL =  _PS_BASE_URL_.__PS_BASE_URI__.'index.php?controller=order-confirmation&id_cart='.(int)$cart->id.'&id_module='.(int)$Forgingblock->id.'&id_order='.(int)$order_id.'&key='.$cart->secure_key;	
		
		
		$notifyURL  = $this->context->link->getModuleLink('forgingblock', 'notify');
		$tmode  = (Configuration::get('FORGINGBLOCK_MODE') == 'N') ? 'live' : 'test';  				
		
		
		$forgingblock = new \ForgingblockAPI($tmode);
		$forgingblock->SetValue('trade',  Configuration::get('FORGINGBLOCK_TRADE_ID'));
		$forgingblock->SetValue('token', Configuration::get('FORGINGBLOCK_TOKEN'));
		$forgingblock->SetValue('amount', round($amount, 2));								
		$forgingblock->SetValue('currency',$currency_code);		
		$forgingblock->SetValue('link', $returnURL);
		$forgingblock->SetValue('notification', $notifyURL);
		$forgingblock->SetValue('order', $order_id);
		$resar = $forgingblock->CreateInvoice();				
		$Error = $forgingblock->GetError();		
			
		if ($Error) {				
			$checkout_type = Configuration::get('PS_ORDER_PROCESS_TYPE') ? 'order-opc' : 'order';
					$url = (_PS_VERSION_ >= '1.5' ? 'index.php?controller='.$checkout_type.'&' : $checkout_type.'.php?').'step=3&cgv=1&forgingblockerror='.$Error.'#forgingblock-anchor';
			Tools::redirect($url);	
			
			exit;							
		}
		else {
			$paymenturl = $forgingblock->GetInvoiceURL();
			$InvoiceID = $forgingblock->GetInvoiceID();	
			$new_order_status =  Configuration::get('FORGINGBLOCK_NEW_SID');
			$this->validateOrder((int)$order_id, (int)$new_order_status, (float)$amount, $this->displayName, null, array(), null, false, $cart->secure_key);
			return  $paymenturl;				
		}			 		

    }


}
